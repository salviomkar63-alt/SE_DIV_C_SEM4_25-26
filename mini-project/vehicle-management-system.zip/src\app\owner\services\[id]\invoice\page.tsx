"use client";

import { useStore } from "@/lib/store";
import { useParams, useRouter } from "next/navigation";
import { ArrowLeft, Printer, FileText, Download, Building2 } from "lucide-react";
import Link from "next/link";
import { use, useEffect, useState } from "react";

export default function InvoicePage() {
  const params = useParams();
  const id = params.id as string;
  const router = useRouter();
  const { services, vehicles } = useStore();
  
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  if (!isClient) return null;

  const service = services.find(s => s.id === id);
  const vehicle = service ? vehicles.find(v => v.id === service.vehicleId) : null;

  if (!service || !vehicle) {
    return (
      <div className="flex flex-col items-center justify-center h-96">
        <FileText className="w-16 h-16 text-slate-600 mb-4" />
        <h2 className="text-2xl font-bold text-white mb-2">Invoice Not Found</h2>
        <p className="text-slate-400 mb-6">The requested service record or vehicle could not be found.</p>
        <Link href="/owner/services" className="px-6 py-2 bg-blue-600 hover:bg-blue-500 rounded-lg text-white font-medium transition-colors cursor-pointer">
          Back to Services
        </Link>
      </div>
    );
  }

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-12">
      <div className="flex items-center justify-between mb-8 print:hidden">
        <div className="flex items-center">
          <button onClick={() => router.back()} className="p-2 mr-4 bg-slate-900 border border-slate-800 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-3xl font-bold text-white mb-1">Invoice</h1>
            <p className="text-slate-400">Reference: {service.reference}</p>
          </div>
        </div>
        <div className="flex gap-3">
          <button onClick={handlePrint} className="flex items-center px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl transition-colors border border-slate-700 cursor-pointer text-sm font-medium">
            <Printer className="w-4 h-4 mr-2" />
            Print
          </button>
          <button onClick={handlePrint} className="flex items-center px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl transition-colors shadow-lg shadow-indigo-500/20 cursor-pointer text-sm font-medium">
            <Download className="w-4 h-4 mr-2" />
            Download PDF
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl p-10 md:p-14 shadow-2xl text-slate-800 print:shadow-none print:p-0">
        {/* Invoice Header */}
        <div className="flex justify-between items-start mb-12 border-b-2 border-slate-100 pb-8">
          <div>
            <div className="flex items-center mb-4">
              <div className="bg-indigo-600 p-2 rounded-lg mr-3">
                <Building2 className="w-6 h-6 text-white" />
              </div>
              <h2 className="text-2xl font-bold text-slate-900 tracking-tight">{service.workshopName}</h2>
            </div>
            <p className="text-slate-500 text-sm">123 Auto Street, Motor City</p>
            <p className="text-slate-500 text-sm">Phone: +91 98765 43210</p>
            <p className="text-slate-500 text-sm">Email: contact@autocarepro.com</p>
          </div>
          <div className="text-right">
            <h1 className="text-4xl font-extrabold text-slate-200 uppercase tracking-widest mb-4">INVOICE</h1>
            <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-sm">
              <span className="text-slate-500 font-medium">Invoice No:</span>
              <span className="font-semibold">{service.reference}</span>
              <span className="text-slate-500 font-medium">Date:</span>
              <span className="font-semibold">{new Date(service.createdAt).toLocaleDateString()}</span>
              <span className="text-slate-500 font-medium">Service Date:</span>
              <span className="font-semibold">{new Date(service.serviceDate).toLocaleDateString()}</span>
            </div>
          </div>
        </div>

        {/* Customer & Vehicle Details */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12 bg-slate-50 rounded-xl p-6 border border-slate-100">
          <div>
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Billed To</h3>
            <p className="font-bold text-lg text-slate-800">{vehicle.ownerName}</p>
            <p className="text-slate-600">Phone: {vehicle.contact}</p>
          </div>
          <div>
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Vehicle Details</h3>
            <p className="font-bold text-lg text-slate-800 flex items-center">
              <span className="bg-slate-200 text-slate-700 px-2 py-0.5 rounded text-sm font-mono mr-2 border border-slate-300">
                {vehicle.vehicleNumber}
              </span>
              {vehicle.model}
            </p>
            <p className="text-slate-600 text-sm mt-1">Service Type: <span className="font-medium text-indigo-600">{service.type}</span></p>
          </div>
        </div>

        {/* Line Items */}
        <div className="mb-12">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b-2 border-slate-200">
                <th className="py-3 font-semibold text-slate-600 w-16">#</th>
                <th className="py-3 font-semibold text-slate-600">Description</th>
                <th className="py-3 font-semibold text-slate-600 text-right">Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              <tr>
                <td className="py-4 text-slate-500">1</td>
                <td className="py-4">
                  <p className="font-bold text-slate-800">General Service Labor</p>
                  <p className="text-sm text-slate-500">Professional inspection and servicing</p>
                </td>
                <td className="py-4 text-right font-semibold">₹{service.serviceCost.toLocaleString()}</td>
              </tr>
              {service.parts.length > 0 && service.parts.map((part, idx) => (
                <tr key={part.id}>
                  <td className="py-4 text-slate-500">{idx + 2}</td>
                  <td className="py-4">
                    <p className="font-bold text-slate-800">{part.name}</p>
                    <p className="text-sm text-slate-500">Replacement Part</p>
                  </td>
                  <td className="py-4 text-right font-semibold">₹{part.cost.toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Totals */}
        <div className="flex justify-end mb-12">
          <div className="w-full md:w-1/2 space-y-3">
            <div className="flex justify-between text-slate-600">
              <span>Subtotal</span>
              <span className="font-semibold">₹{service.totalCost.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>Tax (0%)</span>
              <span className="font-semibold">₹0</span>
            </div>
            <div className="flex justify-between border-t-2 border-slate-800 pt-3 text-xl font-bold text-slate-900">
              <span>Total Amount</span>
              <span className="text-indigo-600">₹{service.totalCost.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t-2 border-slate-100 pt-8 text-center">
          <p className="font-semibold text-slate-800 mb-1">Thank you for your business!</p>
          <p className="text-sm text-slate-500">For any questions about this invoice, please contact us.</p>
        </div>
      </div>
    </div>
  );
}
