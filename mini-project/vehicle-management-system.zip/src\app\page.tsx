"use client";

import { useStore } from "@/lib/store";
import { useRouter } from "next/navigation";
import { Car, Wrench, ArrowRight, User, ShieldCheck, AlertCircle } from "lucide-react";
import { useState } from "react";

export default function LoginPage() {
  const { setRole, setActiveVehicleId, getVehicleByNumber } = useStore();
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<"owner" | "customer">("owner");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Owner credentials state
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  // Customer credentials state
  const [vehicleNumber, setVehicleNumber] = useState("");

  const handleOwnerLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    setTimeout(() => {
      if (username === "admin" && password === "admin123") {
        setRole("owner");
        router.push("/owner");
      } else {
        setError("Invalid username or password");
        setIsLoading(false);
      }
    }, 600);
  };

  const handleCustomerLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    setTimeout(() => {
      const vehicle = getVehicleByNumber(vehicleNumber);
      if (vehicle) {
        setRole("customer");
        setActiveVehicleId(vehicle.id);
        router.push("/customer");
      } else {
        setError("Vehicle not found. Please check your vehicle number.");
        setIsLoading(false);
      }
    }, 600);
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col justify-center items-center p-4 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-96 h-96 bg-blue-600/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-96 h-96 bg-indigo-600/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      <div className="z-10 w-full max-w-md">
        <div className="text-center mb-8 transform translate-y-0 transition-transform duration-500">
          <div className="inline-flex items-center justify-center p-4 bg-slate-900 shadow-2xl rounded-2xl mb-4 border border-slate-800">
            <Wrench className="w-10 h-10 text-blue-500 mr-2" />
            <Car className="w-10 h-10 text-indigo-500" />
          </div>
          <h1 className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-400 mb-2">
            AutoCare Pro
          </h1>
          <p className="text-slate-400 text-lg">Digital Service Management</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl backdrop-blur-xl bg-opacity-80">
          {/* Tabs */}
          <div className="flex bg-slate-800 p-1 rounded-xl mb-6">
            <button
              onClick={() => { setActiveTab("owner"); setError(null); }}
              className={`flex-1 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                activeTab === "owner" ? "bg-slate-700 text-white shadow-sm" : "text-slate-400 hover:text-slate-300"
              }`}
            >
              <div className="flex items-center justify-center">
                <ShieldCheck className="w-4 h-4 mr-2" /> Owner Login
              </div>
            </button>
            <button
              onClick={() => { setActiveTab("customer"); setError(null); }}
              className={`flex-1 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                activeTab === "customer" ? "bg-slate-700 text-white shadow-sm" : "text-slate-400 hover:text-slate-300"
              }`}
            >
              <div className="flex items-center justify-center">
                <User className="w-4 h-4 mr-2" /> Customer Portal
              </div>
            </button>
          </div>

          <h2 className="text-xl font-semibold text-white mb-6 text-center">
            {activeTab === "owner" ? "Welcome Back, Admin" : "Track Your Vehicle"}
          </h2>

          {error && (
            <div className="mb-6 p-3 bg-red-500/10 border border-red-500/20 rounded-xl flex items-center text-red-500 text-sm animate-in fade-in slide-in-from-top-2">
              <AlertCircle className="w-5 h-5 mr-2 shrink-0" />
              {error}
            </div>
          )}

          {activeTab === "owner" ? (
            <form onSubmit={handleOwnerLogin} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-1">Username</label>
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl py-3 px-4 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                  placeholder="admin"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-1">Password</label>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl py-3 px-4 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                  placeholder="••••••••"
                />
              </div>
              <button
                type="submit"
                disabled={isLoading}
                className="w-full mt-6 py-4 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold flex items-center justify-center transition-all shadow-lg shadow-blue-500/20 disabled:opacity-70 disabled:cursor-not-allowed"
              >
                {isLoading ? (
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  <>Sign In to Dashboard <ArrowRight className="w-5 h-5 ml-2" /></>
                )}
              </button>
            </form>
          ) : (
            <form onSubmit={handleCustomerLogin} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-1">Vehicle Number</label>
                <input
                  type="text"
                  required
                  value={vehicleNumber}
                  onChange={(e) => setVehicleNumber(e.target.value.toUpperCase())}
                  className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl py-3 px-4 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-colors uppercase font-mono placeholder:normal-case placeholder:font-sans"
                  placeholder="e.g. KA-01-AB-1234"
                />
              </div>
              <button
                type="submit"
                disabled={isLoading}
                className="w-full mt-6 py-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold flex items-center justify-center transition-all shadow-lg shadow-indigo-500/20 disabled:opacity-70 disabled:cursor-not-allowed"
              >
                {isLoading ? (
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  <>Open Customer Portal <ArrowRight className="w-5 h-5 ml-2" /></>
                )}
              </button>
            </form>
          )}

        </div>
      </div>
    </div>
  );
}
