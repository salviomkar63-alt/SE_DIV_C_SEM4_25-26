"use client";

import { useStore } from "@/lib/store";
import { Plus, Search, Wrench, IndianRupee, FileText, Download } from "lucide-react";
import Link from "next/link";
import { useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";

function ServicesContent() {
  const { services, vehicles } = useStore();
  const searchParams = useSearchParams();
  const vehicleIdParam = searchParams.get("vehicleId");
  
  const [searchTerm, setSearchTerm] = useState("");

  const filteredServices = services.filter((s) => {
    const vehicle = vehicles.find(v => v.id === s.vehicleId);
    const matchesVehicle = vehicleIdParam ? s.vehicleId === vehicleIdParam : true;
    const searchLower = searchTerm.toLowerCase();
    const matchesSearch = 
      (vehicle?.vehicleNumber.toLowerCase().includes(searchLower)) ||
      (s.reference.toLowerCase().includes(searchLower)) ||
      (s.type.toLowerCase().includes(searchLower));
      
    return matchesVehicle && matchesSearch;
  });

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Service History & Invoices</h1>
          <p className="text-slate-400">Manage repair records, parts, and generate invoices.</p>
        </div>
        <Link
          href={`/owner/services/new${vehicleIdParam ? `?vehicleId=${vehicleIdParam}` : ''}`}
          className="inline-flex items-center justify-center px-4 py-2.5 bg-indigo-600 text-white rounded-xl hover:bg-indigo-500 transition-colors shadow-lg shadow-indigo-500/20 font-medium"
        >
          <Plus className="w-5 h-5 mr-2" />
          Log Service
        </Link>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-lg overflow-hidden">
        <div className="p-6 border-b border-slate-800">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 w-5 h-5" />
            <input
              type="text"
              placeholder="Search by reference, vehicle number, or service type..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 text-slate-200 rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
            />
          </div>
        </div>

        {filteredServices.length === 0 ? (
          <div className="py-16 text-center flex flex-col items-center">
            <div className="bg-slate-800 p-4 rounded-full mb-4">
              <Wrench className="w-8 h-8 text-slate-500" />
            </div>
            <h3 className="text-xl font-medium text-white mb-2">No services found</h3>
            <p className="text-slate-400 max-w-sm mx-auto">
              There are no service records matching your search or vehicle filter.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-900/50 text-slate-400 text-sm">
                  <th className="px-6 py-4 font-medium border-b border-slate-800">Reference</th>
                  <th className="px-6 py-4 font-medium border-b border-slate-800">Date</th>
                  <th className="px-6 py-4 font-medium border-b border-slate-800">Vehicle</th>
                  <th className="px-6 py-4 font-medium border-b border-slate-800">Type & Cost</th>
                  <th className="px-6 py-4 font-medium border-b border-slate-800">Parts Used</th>
                  <th className="px-6 py-4 font-medium border-b border-slate-800 text-right">Invoice</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {filteredServices.map((service) => {
                  const vehicle = vehicles.find(v => v.id === service.vehicleId);
                  return (
                    <tr key={service.id} className="hover:bg-slate-800/50 transition-colors">
                      <td className="px-6 py-4">
                        <span className="font-mono text-indigo-400 text-sm">{service.reference}</span>
                      </td>
                      <td className="px-6 py-4 text-slate-300">
                        {new Date(service.serviceDate).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4">
                        {vehicle ? (
                          <>
                            <div className="text-white font-medium">{vehicle.vehicleNumber}</div>
                            <div className="text-xs text-slate-500">{vehicle.ownerName}</div>
                          </>
                        ) : (
                          <span className="text-slate-500">Unknown</span>
                        )}
                      </td>
                      <td className="px-6 py-4">
                        <div className="mb-1">
                          <span className="inline-block bg-slate-800 px-2 py-1 rounded text-xs text-slate-300 border border-slate-700">{service.type}</span>
                        </div>
                        <div className="flex items-center text-sm font-medium text-emerald-400">
                          <IndianRupee className="w-3.5 h-3.5 mr-0.5" />
                          {service.totalCost.toLocaleString()}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        {service.parts.length > 0 ? (
                          <div className="text-sm text-slate-300">
                            {service.parts.length} part(s)
                            <div className="text-xs text-slate-500 truncate max-w-[150px]">
                              {service.parts.map(p => p.name).join(", ")}
                            </div>
                          </div>
                        ) : (
                          <span className="text-sm text-slate-500">None</span>
                        )}
                      </td>
                      <td className="px-6 py-4 text-right">
                        <Link 
                          href={`/owner/services/${service.id}/invoice`}
                          className="inline-flex items-center px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 hover:border-slate-600 text-slate-300 rounded-lg text-sm font-medium transition-all group"
                        >
                          <FileText className="w-4 h-4 mr-2 text-indigo-400 group-hover:text-indigo-300" />
                          View
                        </Link>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

export default function ServicesPage() {
  return (
    <Suspense fallback={<div className="p-8 text-center text-slate-400">Loading services...</div>}>
      <ServicesContent />
    </Suspense>
  );
}
