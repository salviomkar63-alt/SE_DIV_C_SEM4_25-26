"use client";

import React, { createContext, useContext, useState, ReactNode } from "react";

export type Role = "owner" | "customer" | null;

export interface Vehicle {
  id: string;
  vehicleNumber: string;
  model: string;
  ownerName: string;
  contact: string;
  purchaseDate: string;
  createdAt: string;
}

export interface Part {
  id: string;
  name: string;
  cost: number;
}

export interface Service {
  id: string;
  vehicleId: string;
  serviceDate: string;
  type: string;
  serviceCost: number;
  workshopName: string;
  reference: string;
  parts: Part[];
  totalCost: number;
  createdAt: string;
}

interface StoreState {
  role: Role;
  setRole: (role: Role) => void;
  vehicles: Vehicle[];
  services: Service[];
  addVehicle: (vehicle: Omit<Vehicle, "id" | "createdAt">) => void;
  addService: (service: Omit<Service, "id" | "createdAt" | "totalCost">) => void;
  getVehicleByNumber: (vehicleNumber: string) => Vehicle | undefined;
  getServicesForVehicle: (vehicleId: string) => Service[];
  activeVehicleId: string | null;
  setActiveVehicleId: (id: string | null) => void;
}

// Constants
export const PART_CATALOG: Record<string, number> = {
  "Brake Pads": 1200,
  "Engine Oil": 900,
  "Air Filter": 500,
  "Oil Filter": 300,
  "Spark Plug": 250,
  "Clutch Plate": 3500,
  "Battery": 4500,
  "Headlight Bulb": 800,
  "Timing Belt": 1500,
  "Radiator": 5000,
  "Brake Oil": 400,
};

export const SERVICE_RECOMMENDATIONS: Record<string, string[]> = {
  "General Service": ["Engine Oil", "Oil Filter", "Air Filter"],
  "Brake Service": ["Brake Pads", "Brake Oil"],
  "Engine Service": ["Spark Plug", "Engine Oil", "Air Filter"],
};

export const SERVICE_TYPES = ["General Service", "Brake Service", "Engine Service", "Full Servicing", "Other"];

// Initial mock data
const INITIAL_VEHICLES: Vehicle[] = [
  {
    id: "v1",
    vehicleNumber: "KA-01-AB-1234",
    model: "Honda City",
    ownerName: "John Doe",
    contact: "9876543210",
    purchaseDate: "2022-01-15",
    createdAt: "2024-01-01T12:00:00.000Z",
  },
  {
    id: "v2",
    vehicleNumber: "MH-02-CD-5678",
    model: "Hyundai i20",
    ownerName: "Rahul Sharma",
    contact: "9876543211",
    purchaseDate: "2021-06-20",
    createdAt: "2024-01-01T12:00:00.000Z",
  },
  {
    id: "v3",
    vehicleNumber: "DL-04-EF-9012",
    model: "Maruti Swift",
    ownerName: "Amit Kumar",
    contact: "9876543212",
    purchaseDate: "2019-11-10",
    createdAt: "2024-01-01T12:00:00.000Z",
  },
  {
    id: "v4",
    vehicleNumber: "GJ-05-GH-3456",
    model: "Tata Nexon",
    ownerName: "Priya Patel",
    contact: "9876543213",
    purchaseDate: "2023-02-05",
    createdAt: "2024-01-01T12:00:00.000Z",
  },
  {
    id: "v5",
    vehicleNumber: "TN-09-IJ-7890",
    model: "Toyota Innova",
    ownerName: "Suresh Reddy",
    contact: "9876543214",
    purchaseDate: "2020-08-30",
    createdAt: "2024-01-01T12:00:00.000Z",
  },
];

const INITIAL_SERVICES: Service[] = [
  {
    id: "s1",
    vehicleId: "v1",
    serviceDate: "2023-05-10",
    type: "General Maintenance",
    serviceCost: 1500,
    workshopName: "AutoCare Prime",
    reference: "REF-001",
    parts: [
      { id: "p1", name: "Engine Oil", cost: 800 },
      { id: "p2", name: "Oil Filter", cost: 250 },
    ],
    totalCost: 2550,
    createdAt: "2024-01-01T12:00:00.000Z",
  },
];

const StoreContext = createContext<StoreState | undefined>(undefined);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [role, setRole] = useState<Role>(null);
  const [activeVehicleId, setActiveVehicleId] = useState<string | null>(null);
  const [vehicles, setVehicles] = useState<Vehicle[]>(INITIAL_VEHICLES);
  const [services, setServices] = useState<Service[]>(INITIAL_SERVICES);

  const addVehicle = (vehicleData: Omit<Vehicle, "id" | "createdAt">) => {
    const newVehicle: Vehicle = {
      ...vehicleData,
      id: Math.random().toString(36).substr(2, 9),
      createdAt: new Date().toISOString(),
    };
    setVehicles((prev) => [...prev, newVehicle]);
  };

  const addService = (serviceData: Omit<Service, "id" | "createdAt" | "totalCost">) => {
    const partsCost = serviceData.parts.reduce((sum, part) => sum + part.cost, 0);
    const newService: Service = {
      ...serviceData,
      id: Math.random().toString(36).substr(2, 9),
      totalCost: serviceData.serviceCost + partsCost,
      createdAt: new Date().toISOString(),
    };
    setServices((prev) => [...prev, newService]);
  };

  const getVehicleByNumber = (vehicleNumber: string) => {
    return vehicles.find(
      (v) => v.vehicleNumber.toLowerCase() === vehicleNumber.toLowerCase()
    );
  };

  const getServicesForVehicle = (vehicleId: string) => {
    return services.filter((s) => s.vehicleId === vehicleId).sort((a, b) => new Date(b.serviceDate).getTime() - new Date(a.serviceDate).getTime());
  };

  return (
    <StoreContext.Provider
      value={{
        role,
        setRole,
        vehicles,
        services,
        addVehicle,
        addService,
        getVehicleByNumber,
        getServicesForVehicle,
        activeVehicleId,
        setActiveVehicleId,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const context = useContext(StoreContext);
  if (context === undefined) {
    throw new Error("useStore must be used within a StoreProvider");
  }
  return context;
}
