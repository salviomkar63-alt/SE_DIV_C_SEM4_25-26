"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { Car, FileText, LayoutDashboard, LogOut, PlusCircle, Wrench } from "lucide-react";
import { useStore } from "@/lib/store";

const navItems = [
  { name: "Dashboard", href: "/owner", icon: LayoutDashboard },
  { name: "Vehicles", href: "/owner/vehicles", icon: Car },
  { name: "Add Vehicle", href: "/owner/vehicles/new", icon: PlusCircle },
  { name: "Services & Invoices", href: "/owner/services", icon: FileText },
];

export function Sidebar() {
  const pathname = usePathname();
  const router = useRouter();
  const { setRole, setActiveVehicleId } = useStore();

  const handleLogout = () => {
    setRole(null);
    setActiveVehicleId(null);
    router.push("/");
  };

  return (
    <div className="w-64 bg-slate-900 border-r border-slate-800 h-screen flex flex-col hidden md:flex shrink-0">
      <div className="p-6 flex items-center mb-6">
        <div className="bg-blue-600 p-2 rounded-lg mr-3 shadow-lg shadow-blue-500/30">
          <Wrench className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight">AutoCare <span className="text-blue-500">Pro</span></h1>
          <p className="text-xs text-slate-400">Owner Portal</p>
        </div>
      </div>

      <nav className="flex-1 px-4 space-y-2 overflow-y-auto">
        {navItems.map((item) => {
          const isActive = pathname === item.href || (pathname.startsWith(item.href) && item.href !== "/owner");
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center px-4 py-3 rounded-xl transition-all duration-200 group relative overflow-hidden ${
                isActive
                  ? "bg-blue-600/10 text-blue-500"
                  : "text-slate-400 hover:bg-slate-800/50 hover:text-slate-200"
              }`}
            >
              {isActive && (
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-blue-500 rounded-r-md shadow-[0_0_10px_theme('colors.blue.500')]" />
              )}
              <Icon className={`w-5 h-5 mr-3 transition-transform duration-300 ${isActive ? "scale-110" : "group-hover:scale-110 group-hover:text-slate-300"}`} />
              <span className="font-medium">{item.name}</span>
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-slate-800">
        <button
          onClick={handleLogout}
          className="flex items-center w-full px-4 py-3 text-slate-400 hover:text-red-400 hover:bg-red-400/10 rounded-xl transition-colors duration-200"
        >
          <LogOut className="w-5 h-5 mr-3" />
          <span className="font-medium">Logout</span>
        </button>
      </div>
    </div>
  );
}
