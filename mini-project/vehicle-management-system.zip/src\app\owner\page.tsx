"use client";

import { useStore } from "@/lib/store";
import { Car, Wrench, IndianRupee, TrendingUp } from "lucide-react";
import Link from "next/link";

export default function OwnerDashboard() {
  const { vehicles, services } = useStore();

  const totalRevenue = services.reduce((sum, s) => sum + s.totalCost, 0);
  const recentServices = [...services].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).slice(0, 5);

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">Dashboard Overview</h1>
        <p className="text-slate-400">Welcome back! Here's what's happening today.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Stats Cards */}
        <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-lg relative overflow-hidden group">
          <div className="absolute -right-4 -top-4 bg-blue-500/10 w-24 h-24 rounded-full blur-xl group-hover:bg-blue-500/20 transition-all"></div>
          <div className="flex items-center justify-between mb-4 relative z-10">
            <h3 className="text-slate-400 font-medium">Total Vehicles</h3>
            <div className="bg-blue-500/20 p-2 rounded-lg"><Car className="text-blue-500 w-5 h-5" /></div>
          </div>
          <p className="text-3xl font-bold text-white relative z-10">{vehicles.length}</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-lg relative overflow-hidden group">
          <div className="absolute -right-4 -top-4 bg-indigo-500/10 w-24 h-24 rounded-full blur-xl group-hover:bg-indigo-500/20 transition-all"></div>
          <div className="flex items-center justify-between mb-4 relative z-10">
            <h3 className="text-slate-400 font-medium">Total Services</h3>
            <div className="bg-indigo-500/20 p-2 rounded-lg"><Wrench className="text-indigo-400 w-5 h-5" /></div>
          </div>
          <p className="text-3xl font-bold text-white relative z-10">{services.length}</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-lg relative overflow-hidden group">
          <div className="absolute -right-4 -top-4 bg-emerald-500/10 w-24 h-24 rounded-full blur-xl group-hover:bg-emerald-500/20 transition-all"></div>
          <div className="flex items-center justify-between mb-4 relative z-10">
            <h3 className="text-slate-400 font-medium">Total Revenue</h3>
            <div className="bg-emerald-500/20 p-2 rounded-lg"><IndianRupee className="text-emerald-400 w-5 h-5" /></div>
          </div>
          <p className="text-3xl font-bold text-white relative z-10 flex items-baseline gap-2">
            ₹{totalRevenue.toLocaleString()}
            <span className="text-sm font-normal text-emerald-400 flex items-center"><TrendingUp className="w-3 h-3 mr-1" /> All Time</span>
          </p>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-lg overflow-hidden">
        <div className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-800/20">
          <h2 className="text-xl font-bold text-white">Recent Service Activity</h2>
          <Link href="/owner/services" className="text-sm text-blue-400 hover:text-blue-300 font-medium">View All</Link>
        </div>
        
        {recentServices.length === 0 ? (
          <div className="p-8 text-center text-slate-500">No services recorded yet.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-900/50 text-slate-400 text-sm">
                  <th className="px-6 py-4 font-medium">Reference</th>
                  <th className="px-6 py-4 font-medium">Vehicle ID</th>
                  <th className="px-6 py-4 font-medium">Service Date</th>
                  <th className="px-6 py-4 font-medium">Type</th>
                  <th className="px-6 py-4 font-medium text-right">Cost</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {recentServices.map((service) => {
                  const vehicle = vehicles.find(v => v.id === service.vehicleId);
                  return (
                    <tr key={service.id} className="hover:bg-slate-800/50 transition-colors">
                      <td className="px-6 py-4 font-mono text-sm text-blue-400">{service.reference}</td>
                      <td className="px-6 py-4">
                        <div className="text-white font-medium">{vehicle?.vehicleNumber || 'Unknown'}</div>
                        <div className="text-xs text-slate-500">{vehicle?.model}</div>
                      </td>
                      <td className="px-6 py-4 text-slate-300">{new Date(service.serviceDate).toLocaleDateString()}</td>
                      <td className="px-6 py-4 text-slate-300 bg-slate-800/30 rounded inline-block m-3 ml-6 mb-2 mt-4 px-2 py-1 text-xs">{service.type}</td>
                      <td className="px-6 py-4 text-right font-medium text-white">₹{service.totalCost.toLocaleString()}</td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
