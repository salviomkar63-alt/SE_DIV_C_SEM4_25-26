"use client";

import { useStore } from "@/lib/store";
import { Car, Calendar, FileText, Wrench, PackageSearch } from "lucide-react";
import Link from "next/link";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

export default function CustomerDashboard() {
  const { vehicles, services, activeVehicleId } = useStore();
  const router = useRouter();
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
    if (!activeVehicleId) {
      router.push("/");
    }
  }, [activeVehicleId, router]);

  if (!isClient) return null;

  const searchedVehicle = activeVehicleId ? vehicles.find(v => v.id === activeVehicleId) : null;
  const vehicleServices = searchedVehicle 
    ? services.filter(srv => srv.vehicleId === searchedVehicle.id).sort((a,b) => new Date(b.serviceDate).getTime() - new Date(a.serviceDate).getTime())
    : [];

  if (!searchedVehicle) {
    return (
      <div className="flex justify-center items-center h-64 text-slate-400">
        <div className="animate-pulse">Loading secure records...</div>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="mb-10 max-w-2xl mx-auto text-center">
        <h1 className="text-4xl font-extrabold text-white mb-4">Your Vehicle Portal</h1>
        <p className="text-lg text-slate-400">View complete maintenance records, parts replaced, and invoices securely.</p>
      </div>

      <div className="max-w-4xl mx-auto space-y-8">
        {/* Vehicle Info Card */}
        <div className="bg-slate-900 border border-slate-800 flex flex-col md:flex-row rounded-3xl overflow-hidden shadow-2xl">
          <div className="bg-indigo-600/10 p-8 md:w-1/3 flex flex-col items-center justify-center border-b md:border-b-0 md:border-r border-slate-800">
            <div className="bg-slate-900 p-4 rounded-full mb-4 shadow-inner">
              <Car className="w-12 h-12 text-indigo-400" />
            </div>
            <div className="text-2xl font-black font-mono text-white tracking-widest bg-slate-800 px-4 py-1.5 rounded-lg border border-slate-700 shadow-sm text-center">
              {searchedVehicle.vehicleNumber}
            </div>
          </div>
          <div className="p-8 md:w-2/3 flex flex-col justify-center">
            <h2 className="text-2xl font-bold text-white mb-6">{searchedVehicle.model}</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-4 gap-x-8">
              <div>
                <div className="text-sm font-medium text-slate-500 mb-1 tracking-wide uppercase">Owner Name</div>
                <div className="text-lg font-medium text-slate-200">{searchedVehicle.ownerName}</div>
              </div>
              <div>
                <div className="text-sm font-medium text-slate-500 mb-1 tracking-wide uppercase">Purchase Date</div>
                <div className="text-lg font-medium text-slate-200 flex items-center">
                  <Calendar className="w-4 h-4 mr-2 text-indigo-400" />
                  {new Date(searchedVehicle.purchaseDate).toLocaleDateString()}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Service History Timeline */}
        <div>
          <h3 className="text-2xl font-bold text-white mb-6 flex items-center">
            <Wrench className="w-6 h-6 mr-3 text-indigo-400" /> Service History
          </h3>
          
          {vehicleServices.length === 0 ? (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center shadow-lg">
              <p className="text-slate-400">No service records exist for this vehicle yet.</p>
            </div>
          ) : (
            <div className="space-y-6">
              {vehicleServices.map((service, idx) => (
                <div key={service.id} className="relative pl-8 md:pl-0">
                  {/* Timeline Line (Mobile mostly) */}
                  <div className="md:hidden absolute left-[15px] top-0 bottom-0 w-0.5 bg-slate-800"></div>
                  
                  <div className="bg-slate-900 border border-slate-800 hover:border-indigo-500/50 rounded-2xl p-6 md:p-8 shadow-lg transition-all relative overflow-hidden group">
                    <div className="md:hidden absolute left-[11px] top-8 w-2 h-2 rounded-full bg-indigo-500 ring-4 ring-slate-900"></div>
                    
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-6">
                      <div>
                        <div className="flex items-center gap-3 mb-2">
                          <span className="bg-slate-800 text-indigo-300 text-xs font-bold px-3 py-1 rounded-full border border-slate-700">
                            {new Date(service.serviceDate).toLocaleDateString()}
                          </span>
                          <span className="font-mono text-xs text-slate-500">#{service.reference}</span>
                        </div>
                        <h4 className="text-xl font-bold text-white">{service.type}</h4>
                        <p className="text-slate-400 text-sm mt-1">at <span className="text-slate-300 font-medium">{service.workshopName}</span></p>
                      </div>
                      
                      <div className="text-left md:text-right shrink-0 bg-slate-800/50 p-4 rounded-xl border border-slate-700/50">
                        <div className="text-sm font-medium text-slate-400 mb-1 uppercase">Total Cost</div>
                        <div className="text-3xl font-bold text-emerald-400 tracking-tight">₹{service.totalCost.toLocaleString()}</div>
                        <Link 
                          href={`/customer/invoice/${service.id}`}
                          className="inline-flex items-center mt-3 text-sm font-medium text-indigo-400 hover:text-indigo-300 group/link"
                        >
                          <FileText className="w-4 h-4 mr-1.5" />
                          View Full Invoice
                          <span className="transform translate-x-0 group-hover/link:translate-x-1 transition-transform inline-block ml-1">&rarr;</span>
                        </Link>
                      </div>
                    </div>

                    {service.parts.length > 0 && (
                      <div className="border-t border-slate-800 pt-6">
                        <h5 className="text-sm font-bold text-slate-300 uppercase tracking-wider mb-4 flex items-center">
                          <PackageSearch className="w-4 h-4 mr-2 text-slate-500" />
                          Parts Replaced
                        </h5>
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                          {service.parts.map(part => (
                            <div key={part.id} className="bg-slate-800/80 rounded-lg p-3 border border-slate-700 flex justify-between items-center group-hover:bg-slate-800 transition-colors">
                              <span className="text-slate-200 font-medium text-sm">{part.name}</span>
                              <span className="text-slate-400 text-xs font-mono ml-2">₹{part.cost}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
