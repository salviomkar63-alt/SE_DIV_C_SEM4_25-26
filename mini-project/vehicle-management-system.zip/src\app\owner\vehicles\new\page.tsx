"use client";

import { useStore } from "@/lib/store";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { ArrowLeft, CarFront, CheckCircle2, User, Phone, Calendar, Loader2 } from "lucide-react";
import Link from "next/link";

export default function AddVehiclePage() {
  const { addVehicle } = useStore();
  const router = useRouter();
  
  const [formData, setFormData] = useState({
    vehicleNumber: "",
    model: "",
    ownerName: "",
    contact: "",
    purchaseDate: new Date().toISOString().split('T')[0],
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    setTimeout(() => {
      addVehicle(formData);
      setIsSubmitting(false);
      setSuccess(true);
      
      setTimeout(() => {
        router.push("/owner/vehicles");
      }, 1500);
    }, 600);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center mb-8">
        <Link href="/owner/vehicles" className="p-2 mr-4 bg-slate-900 border border-slate-800 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white transition-colors">
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <div>
          <h1 className="text-3xl font-bold text-white mb-1">Add New Vehicle</h1>
          <p className="text-slate-400">Register a customer vehicle to track its service history.</p>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl overflow-hidden relative">
        {success && (
          <div className="absolute inset-0 bg-slate-900/90 backdrop-blur-sm z-20 flex flex-col items-center justify-center animate-in fade-in duration-300">
            <div className="bg-emerald-500/20 p-4 rounded-full mb-4">
              <CheckCircle2 className="w-12 h-12 text-emerald-500" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">Vehicle Added!</h2>
            <p className="text-slate-400">Redirecting back to registry...</p>
          </div>
        )}

        <div className="p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-300 flex items-center">
                  <span className="w-6 h-6 mr-2 bg-slate-800 rounded flex items-center justify-center text-slate-400"><CarFront className="w-3.5 h-3.5" /></span>
                  Vehicle Number
                </label>
                <input
                  required
                  type="text"
                  name="vehicleNumber"
                  value={formData.vehicleNumber}
                  onChange={handleChange}
                  placeholder="e.g. MH-12-AB-3456"
                  className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl py-3 px-4 focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono uppercase transition-colors"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-300 flex items-center">
                  <span className="w-6 h-6 mr-2 bg-slate-800 rounded flex items-center justify-center text-slate-400"><CarFront className="w-3.5 h-3.5" /></span>
                  Vehicle Model
                </label>
                <input
                  required
                  type="text"
                  name="model"
                  value={formData.model}
                  onChange={handleChange}
                  placeholder="e.g. Hyundai Creta, Honda City"
                  className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl py-3 px-4 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-300 flex items-center">
                  <span className="w-6 h-6 mr-2 bg-slate-800 rounded flex items-center justify-center text-slate-400"><User className="w-3.5 h-3.5" /></span>
                  Owner Name
                </label>
                <input
                  required
                  type="text"
                  name="ownerName"
                  value={formData.ownerName}
                  onChange={handleChange}
                  placeholder="Customer's full name"
                  className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl py-3 px-4 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-300 flex items-center">
                  <span className="w-6 h-6 mr-2 bg-slate-800 rounded flex items-center justify-center text-slate-400"><Phone className="w-3.5 h-3.5" /></span>
                  Contact Number
                </label>
                <input
                  required
                  type="tel"
                  name="contact"
                  value={formData.contact}
                  onChange={handleChange}
                  placeholder="e.g. 9876543210"
                  className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl py-3 px-4 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                />
              </div>

              <div className="space-y-2 md:col-span-2">
                <label className="text-sm font-medium text-slate-300 flex items-center">
                  <span className="w-6 h-6 mr-2 bg-slate-800 rounded flex items-center justify-center text-slate-400"><Calendar className="w-3.5 h-3.5" /></span>
                  Purchase Date
                </label>
                <input
                  required
                  type="date"
                  name="purchaseDate"
                  value={formData.purchaseDate}
                  onChange={handleChange}
                  className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl py-3 px-4 focus:ring-2 focus:ring-blue-500 focus:border-transparent cursor-pointer transition-colors"
                />
              </div>
            </div>

            <div className="pt-6 border-t border-slate-800/50 flex justify-end">
              <Link 
                href="/owner/vehicles"
                className="px-6 py-3 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors font-medium mr-4"
              >
                Cancel
              </Link>
              <button
                type="submit"
                disabled={isSubmitting || success}
                className="px-8 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl transition-colors shadow-lg shadow-blue-500/20 font-medium flex items-center disabled:opacity-70 disabled:cursor-not-allowed"
              >
                {isSubmitting ? (
                  <><Loader2 className="w-5 h-5 mr-2 animate-spin" /> Saving...</>
                ) : (
                  'Register Vehicle'
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
