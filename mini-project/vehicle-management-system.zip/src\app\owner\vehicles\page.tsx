"use client";

import { useStore } from "@/lib/store";
import { Plus, Search, Car, Calendar, User, Phone } from "lucide-react";
import Link from "next/link";
import { useState } from "react";

export default function VehiclesPage() {
  const { vehicles } = useStore();
  const [searchTerm, setSearchTerm] = useState("");

  const filteredVehicles = vehicles.filter((v) =>
    v.vehicleNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
    v.ownerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    v.model.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Vehicles Registry</h1>
          <p className="text-slate-400">Manage customer vehicles and service history.</p>
        </div>
        <Link
          href="/owner/vehicles/new"
          className="inline-flex items-center justify-center px-4 py-2.5 bg-blue-600 text-white rounded-xl hover:bg-blue-500 transition-colors shadow-lg shadow-blue-500/20 font-medium"
        >
          <Plus className="w-5 h-5 mr-2" />
          Add Vehicle
        </Link>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-lg">
        <div className="relative mb-6">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 w-5 h-5" />
          <input
            type="text"
            placeholder="Search by vehicle number, model, or owner name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-800 border border-slate-700 text-slate-200 rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
          />
        </div>

        {filteredVehicles.length === 0 ? (
          <div className="py-12 text-center flex flex-col items-center">
            <div className="bg-slate-800 p-4 rounded-full mb-4">
              <Car className="w-8 h-8 text-slate-500" />
            </div>
            <h3 className="text-xl font-medium text-white mb-2">No vehicles found</h3>
            <p className="text-slate-400 max-w-sm mx-auto">
              Cannot find any vehicles matching your search criteria. Try a different term or register a new one.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredVehicles.map((vehicle) => (
              <div key={vehicle.id} className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-5 hover:border-blue-500/50 hover:bg-slate-800 transition-all group">
                <div className="flex items-start justify-between mb-4">
                  <div className="inline-block px-3 py-1 bg-blue-500/20 text-blue-400 text-sm font-bold font-mono rounded-lg border border-blue-500/20 group-hover:border-blue-500/50 transition-colors">
                    {vehicle.vehicleNumber}
                  </div>
                  <div className="p-1.5 bg-slate-700/50 rounded-lg">
                    <Car className="w-4 h-4 text-slate-400" />
                  </div>
                </div>
                
                <h3 className="text-lg font-bold text-white mb-4">{vehicle.model}</h3>
                
                <div className="space-y-2 mb-6">
                  <div className="flex items-center text-sm text-slate-400">
                    <User className="w-4 h-4 mr-2 text-slate-500" />
                    {vehicle.ownerName}
                  </div>
                  <div className="flex items-center text-sm text-slate-400">
                    <Phone className="w-4 h-4 mr-2 text-slate-500" />
                    {vehicle.contact}
                  </div>
                  <div className="flex items-center text-sm text-slate-400">
                    <Calendar className="w-4 h-4 mr-2 text-slate-500" />
                    Purchased: {new Date(vehicle.purchaseDate).toLocaleDateString()}
                  </div>
                </div>
                
                <div className="pt-4 border-t border-slate-700">
                  <Link 
                    href={`/owner/services?vehicleId=${vehicle.id}`}
                    className="text-sm font-medium text-indigo-400 hover:text-indigo-300 flex items-center transition-colors"
                  >
                    View Services &rarr;
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
