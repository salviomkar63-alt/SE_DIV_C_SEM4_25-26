"use client";

import { useStore, Part, PART_CATALOG, SERVICE_RECOMMENDATIONS, SERVICE_TYPES } from "@/lib/store";
import { useRouter, useSearchParams } from "next/navigation";
import { useState, Suspense, useEffect } from "react";
import { ArrowLeft, Car, Calendar, CheckCircle2, Loader2, PlusCircle, Trash2, Tag, Component, Receipt } from "lucide-react";
import Link from "next/link";

function AddServiceContent() {
  const { addService, vehicles } = useStore();
  const searchParams = useSearchParams();
  const router = useRouter();
  const initialVehicleId = searchParams.get("vehicleId") || "";

  const [formData, setFormData] = useState({
    vehicleId: initialVehicleId,
    serviceDate: new Date().toISOString().split('T')[0],
    type: "General Service",
    serviceCost: 500,
    workshopName: "AutoCare Pro Main Garage",
    reference: `REF-${Math.floor(100000 + Math.random() * 900000)}`,
  });

  const [parts, setParts] = useState<Omit<Part, "id">[]>([]);
  const [partInput, setPartInput] = useState({ name: "", cost: 0 });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  // Set the first vehicle if none selected and vehicles exist
  useEffect(() => {
    if (!formData.vehicleId && vehicles.length > 0) {
      setFormData(prev => ({ ...prev, vehicleId: vehicles[0].id }));
    }
  }, [vehicles, formData.vehicleId]);

  const handleAddPart = () => {
    if (partInput.name && partInput.cost >= 0) {
      setParts([...parts, { name: partInput.name, cost: partInput.cost }]);
      setPartInput({ name: "", cost: 0 });
    }
  };

  const handleRemovePart = (index: number) => {
    setParts(parts.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.vehicleId) return;

    setIsSubmitting(true);
    
    setTimeout(() => {
      addService({
        ...formData,
        serviceCost: Number(formData.serviceCost),
        parts: parts.map(p => ({ ...p, id: Math.random().toString(36).substr(2, 9) }))
      });
      setIsSubmitting(false);
      setSuccess(true);
      
      setTimeout(() => {
        router.push("/owner/services");
      }, 1500);
    }, 600);
  };

  const totalCost = Number(formData.serviceCost) + parts.reduce((sum, p) => sum + p.cost, 0);

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center mb-8">
        <button onClick={() => router.back()} className="p-2 mr-4 bg-slate-900 border border-slate-800 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white transition-colors">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div>
          <h1 className="text-3xl font-bold text-white mb-1">Log New Service</h1>
          <p className="text-slate-400">Record maintenance details, add replaced parts, and generate invoice.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl overflow-hidden relative">
            {success && (
              <div className="absolute inset-0 bg-slate-900/90 backdrop-blur-sm z-20 flex flex-col items-center justify-center animate-in fade-in duration-300">
                <div className="bg-emerald-500/20 p-4 rounded-full mb-4">
                  <CheckCircle2 className="w-12 h-12 text-emerald-500" />
                </div>
                <h2 className="text-2xl font-bold text-white mb-2">Service Logged!</h2>
                <p className="text-slate-400">Redirecting...</p>
              </div>
            )}

            <div className="p-8">
              <form onSubmit={handleSubmit} className="space-y-8">
                {/* Service Details Section */}
                <div className="space-y-6">
                  <h3 className="text-lg font-bold text-white flex items-center border-b border-slate-800 pb-2">
                    <Receipt className="w-5 h-5 mr-2 text-indigo-400" /> General Details
                  </h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2 col-span-1 md:col-span-2">
                      <label className="text-sm font-medium text-slate-300 flex items-center">
                        <Car className="w-4 h-4 mr-2 text-slate-400" /> Select Vehicle
                      </label>
                      {vehicles.length === 0 ? (
                        <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-xl text-amber-500 text-sm">
                          No vehicles found. Please register a vehicle first.
                        </div>
                      ) : (
                        <select
                          required
                          value={formData.vehicleId}
                          onChange={(e) => setFormData({...formData, vehicleId: e.target.value})}
                          className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl py-3 px-4 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-colors appearance-none"
                        >
                          <option value="" disabled>Select a vehicle...</option>
                          {vehicles.map(v => (
                            <option key={v.id} value={v.id}>{v.vehicleNumber} ({v.model} - {v.ownerName})</option>
                          ))}
                        </select>
                      )}
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium text-slate-300 flex items-center">
                        <Tag className="w-4 h-4 mr-2 text-slate-400" /> Service Type
                      </label>
                      <select
                        required
                        value={formData.type}
                        onChange={(e) => setFormData({...formData, type: e.target.value})}
                        className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl py-3 px-4 focus:ring-2 focus:ring-indigo-500 focus:border-transparent appearance-none"
                      >
                        <option value="" disabled>Select service type...</option>
                        {SERVICE_TYPES.map(t => (
                          <option key={t} value={t}>{t}</option>
                        ))}
                      </select>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium text-slate-300 flex items-center">
                        <Calendar className="w-4 h-4 mr-2 text-slate-400" /> Service Date
                      </label>
                      <input
                        required
                        type="date"
                        value={formData.serviceDate}
                        onChange={(e) => setFormData({...formData, serviceDate: e.target.value})}
                        className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl py-3 px-4 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                      />
                    </div>
                  </div>
                </div>

                {/* Parts Section */}
                <div className="space-y-6 pt-4">
                  <h3 className="text-lg font-bold text-white flex items-center border-b border-slate-800 pb-2">
                    <Component className="w-5 h-5 mr-2 text-indigo-400" /> Replaced Parts
                  </h3>

                  {formData.type && SERVICE_RECOMMENDATIONS[formData.type] && (
                    <div className="bg-indigo-500/10 border border-indigo-500/20 p-4 rounded-xl animate-in fade-in duration-300">
                      <p className="text-xs text-indigo-300 font-semibold uppercase tracking-wider mb-3">Recommended for {formData.type}</p>
                      <div className="flex flex-wrap gap-2">
                        {SERVICE_RECOMMENDATIONS[formData.type].map(partName => (
                          <button
                            type="button"
                            key={partName}
                            onClick={() => {
                               setParts([...parts, { name: partName, cost: PART_CATALOG[partName] || 0 }]);
                            }}
                            className="text-sm bg-slate-800 border border-indigo-500/30 hover:bg-slate-700 hover:border-indigo-400 text-indigo-200 px-3 py-1.5 rounded-lg flex items-center transition-colors shadow-sm"
                          >
                            <PlusCircle className="w-3.5 h-3.5 mr-1.5" />
                            {partName}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-700/50">
                    <div className="flex gap-4 items-end">
                      <div className="flex-1 space-y-1">
                        <label className="text-xs text-slate-400">Part Name</label>
                        <input
                          type="text"
                          list="parts-list"
                          value={partInput.name}
                          onChange={(e) => {
                            const val = e.target.value;
                            if (PART_CATALOG[val] !== undefined) {
                              setPartInput({...partInput, name: val, cost: PART_CATALOG[val]});
                            } else {
                              setPartInput({...partInput, name: val});
                            }
                          }}
                          placeholder="e.g. Brake Pads"
                          className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg py-2 px-3 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                        />
                        <datalist id="parts-list">
                          {Object.keys(PART_CATALOG).map(p => (
                            <option key={p} value={p} />
                          ))}
                        </datalist>
                      </div>
                      <div className="w-32 space-y-1">
                        <label className="text-xs text-slate-400">Cost (₹)</label>
                        <input
                          type="number"
                          min="0"
                          value={partInput.cost || ""}
                          onChange={(e) => setPartInput({...partInput, cost: Number(e.target.value)})}
                          placeholder="0"
                          className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg py-2 px-3 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                        />
                      </div>
                      <button
                        type="button"
                        onClick={handleAddPart}
                        disabled={!partInput.name || partInput.cost < 0}
                        className="p-2 border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg transition-colors disabled:opacity-50"
                      >
                        <PlusCircle className="w-5 h-5" />
                      </button>
                    </div>

                    {parts.length > 0 && (
                      <div className="mt-4 pt-4 border-t border-slate-700/50 space-y-2">
                        {parts.map((part, idx) => (
                          <div key={idx} className="flex justify-between items-center bg-slate-800 p-3 rounded-lg border border-slate-700">
                            <span className="text-sm font-medium text-slate-200">{part.name}</span>
                            <div className="flexItems-center space-x-4">
                              <span className="text-sm text-emerald-400 font-medium">₹{part.cost}</span>
                              <button
                                type="button"
                                onClick={() => handleRemovePart(idx)}
                                className="text-red-400 hover:bg-red-400/10 p-1.5 rounded-lg transition-colors"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                <div className="pt-6 border-t border-slate-800/50 flex justify-end">
                  <button
                    type="submit"
                    disabled={isSubmitting || success || vehicles.length === 0}
                    className="px-8 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl transition-colors shadow-lg shadow-indigo-500/20 font-medium flex items-center disabled:opacity-70 disabled:cursor-not-allowed"
                  >
                    {isSubmitting ? (
                      <><Loader2 className="w-5 h-5 mr-2 animate-spin" /> Saving...</>
                    ) : (
                      'Save Record & Generate Invoice'
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>

        {/* Invoice Preview Synopsis */}
        <div className="lg:col-span-1 border-l border-slate-800 lg:pl-8 pt-8 lg:pt-0">
          <div className="sticky top-8">
            <h3 className="text-lg font-bold text-white mb-6">Financial Summary</h3>
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
               <div>
                 <label className="text-xs text-slate-400 uppercase tracking-wider font-semibold block mb-2">Service Fee (Labor)</label>
                 <div className="relative">
                   <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">₹</span>
                   <input
                     type="number"
                     min="0"
                     required
                     value={formData.serviceCost || ""}
                     onChange={(e) => setFormData({...formData, serviceCost: Number(e.target.value)})}
                     className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl py-2 pl-8 pr-4 focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                   />
                 </div>
               </div>

               <div className="pt-4 border-t border-slate-800">
                 <div className="flex justify-between text-sm text-slate-400 mb-2">
                   <span>Service Cost</span>
                   <span>₹{Number(formData.serviceCost).toLocaleString()}</span>
                 </div>
                 <div className="flex justify-between text-sm text-slate-400 mb-4">
                   <span>Parts Total ({parts.length})</span>
                   <span>₹{parts.reduce((sum, p) => sum + p.cost, 0).toLocaleString()}</span>
                 </div>
                 
                 <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl flex justify-between items-center text-emerald-400 font-bold text-lg shadow-[0_0_15px_rgba(16,185,129,0.1)]">
                   <span>Total Amount</span>
                   <span>₹{totalCost.toLocaleString()}</span>
                 </div>
               </div>
               
               <p className="text-xs text-slate-500 text-center mt-4">
                 Invoice Reference: <span className="font-mono text-slate-400">{formData.reference}</span>
               </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function AddServicePage() {
  return (
    <Suspense fallback={<div className="p-8 text-center text-slate-400">Loading form...</div>}>
      <AddServiceContent />
    </Suspense>
  )
}
