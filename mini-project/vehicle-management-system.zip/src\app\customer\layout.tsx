"use client";

import { useStore } from "@/lib/store";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { LogOut, User as UserIcon } from "lucide-react";
import Link from "next/link";

export default function CustomerLayout({ children }: { children: React.ReactNode }) {
  const { role, setRole, setActiveVehicleId } = useStore();
  const router = useRouter();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    if (role !== "customer") {
      router.push("/");
    }
  }, [role, router]);

  if (!mounted || role !== "customer") {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200">
      {/* Dynamic Background Elements */}
      <div className="fixed top-0 left-0 w-full h-full overflow-hidden pointer-events-none z-0">
        <div className="absolute top-[-10%] left-[20%] w-[500px] h-[500px] bg-indigo-600/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-[-10%] right-[10%] w-96 h-96 bg-blue-600/10 rounded-full blur-3xl"></div>
      </div>

      {/* Top Navbar */}
      <nav className="relative z-20 bg-slate-900/80 backdrop-blur-md border-b border-slate-800 sticky top-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <Link href="/customer" className="flex items-center">
                <div className="bg-indigo-600 p-1.5 rounded-md mr-3 text-white">
                  <UserIcon className="w-5 h-5" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-white tracking-tight">AutoCare <span className="text-indigo-400">Portal</span></h1>
                </div>
              </Link>
            </div>
            
            <div>
              <button
                onClick={() => {
                  setRole(null);
                  setActiveVehicleId(null);
                  router.push("/");
                }}
                className="flex items-center px-4 py-2 text-sm text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors border border-slate-700"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Sign Out
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 lg:py-12">
        {children}
      </main>
    </div>
  );
}
